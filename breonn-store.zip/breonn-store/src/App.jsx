import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import './index.css';

const plans = [
  { days: '1 Dia', url: 'https://go.tribopay.com.br/qqfmley8qp?affh=x5wgclgrn0' },
  { days: '3 Dias', url: 'https://go.tribopay.com.br/uumgyfiarg?affh=hhveq7ou8t' },
  { days: '7 Dias', url: 'https://go.tribopay.com.br/u55svgvlpt?affh=wrh4k07eft' },
  { days: '15 Dias', url: 'https://go.tribopay.com.br/dqdqq3dsif?affh=wxku54jbmb' },
  { days: '30 Dias', url: 'https://go.tribopay.com.br/i8qvxtthwf?affh=hsub5toe4i' }
];

function App() {
  const [particles, setParticles] = useState([]);

  useEffect(() => {
    const interval = setInterval(() => {
      setParticles(prev => [...prev, { id: Date.now(), x: Math.random() * 100 }]);
    }, 300);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0e0e11] via-[#1a1a2e] to-[#16213e] text-white overflow-hidden relative">
      {particles.map(particle => (
        <motion.div
          key={particle.id}
          className="absolute w-[4px] h-[4px] bg-[#00ff88] rounded-full"
          style={{ left: `${particle.x}%` }}
          initial={{ y: '100vh', scale: 0, opacity: 0 }}
          animate={{ y: '-100px', scale: 1, opacity: [0, 1, 1, 0] }}
          transition={{ duration: 6, ease: 'linear' }}
          onAnimationComplete={() => setParticles(prev => prev.filter(p => p.id !== particle.id))}
        />
      ))}

      <motion.img
        src="/banner.jpg"
        alt="BREONN STORE"
        className="w-full h-[250px] object-cover brightness-110 contrast-[1.05]"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      />

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="max-w-6xl mx-auto px-5 py-12"
      >
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="font-orbitron text-5xl md:text-[4.5rem] mb-4 bg-gradient-to-r from-[#00ff88] via-[#00cc6a] to-[#00ff88] bg-clip-text text-transparent drop-shadow-glow"
          style={{ textShadow: '0 0 20px rgba(0, 255, 136, 0.5)' }}
        >
          BREONN STORE
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="text-xl text-gray-400 font-light mb-10"
        >
          Pato Team - Escolha seu período
        </motion.p>

        <motion.a
          href="https://t.me/breonnmodz"
          target="_blank"
          rel="noopener"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          whileHover={{ y: -3, scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="block mx-auto mb-12 px-10 py-4 bg-gradient-to-r from-[#1f1f26] to-[#2a2a33] border-2 border-[#00ff88] rounded-full text-lg font-medium max-w-max shadow-[0_8px_25px_rgba(0,255,136,0.2)] hover:shadow-[0_15px_35px_rgba(0,255,136,0.4)] hover:bg-gradient-to-r hover:from-[#00ff88] hover:to-[#00cc6a] hover:text-black transition-all duration-400"
        >
          Falar no Telegram
        </motion.a>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
          className="bg-[#00ff88]/10 border border-[#00ff88]/30 rounded-2xl p-5 mb-10 text-gray-300 text-sm max-w-2xl mx-auto"
        >
          📱 <strong>Problema no Telegram?</strong><br />
          Segure "Comprar" → "Abrir no navegador" ou copie pro Chrome!
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-8">
          <AnimatePresence>
            {plans.map((plan, index) => (
              <motion.div
                key={plan.days}
                initial={{ opacity: 0, y: 20, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
                whileHover={{ y: -12, scale: 1.02, boxShadow: '0 25px 50px rgba(0, 255, 136, 0.3)' }}
                className="group bg-[#15151b]/80 backdrop-blur-xl rounded-3xl p-8 border border-[#22222b]/50 hover:border-[#00ff88] hover:bg-[#15151b]/95 transition-all duration-400 relative overflow-hidden"
              >
                <motion.div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-[#00ff88] via-[#00cc6a] to-[#00ff88] opacity-0" 
                            initial={{ opacity: 0 }} whileHover={{ opacity: 1 }} transition={{ duration: 0.3 }} />
                
                <motion.h2 className="font-orbitron text-2xl mb-6 bg-gradient-to-r from-white to-gray-200 bg-clip-text text-transparent"
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.05 + 0.2 }}>
                  {plan.days}
                </motion.h2>
                
                <motion.a href={plan.url} target="_blank" rel="noopener"
                          className="block w-full py-3.5 px-8 bg-gradient-to-r from-[#00ff88] to-[#00cc6a] text-black font-bold uppercase text-base rounded-2xl shadow-[0_8px_20px_rgba(0,255,136,0.4)] hover:shadow-[0_15px_30px_rgba(0,255,136,0.6)] hover:-translate-y-2 hover:scale-[1.05] transition-all duration-300"
                          whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.98 }}>
                  Comprar
                </motion.a>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}

export default App;